import { useState } from "react";

const leads = [
  { name: "Jane Doe", email: "jane@example.com", service: "Surveillance", description: "Suspicious behavior at work." },
  { name: "Mark Silva", email: "mark@example.com", service: "Fraud/Theft Investigation", description: "Tracking possible embezzlement." }
];

export default function HomePage() {
  const [submitted, setSubmitted] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [password, setPassword] = useState("");
  const [formData, setFormData] = useState({ name: "", email: "", service: "", description: "", ai_opt_in: "yes", file: null });

  const handleChange = (e) => {
    const { name, value, files } = e.target;
    if (name === "file") {
      setFormData({ ...formData, file: files[0] });
    } else {
      setFormData({ ...formData, [name]: value });
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitted(true);

    const data = new FormData();
    Object.entries(formData).forEach(([key, value]) => {
      if (value) data.append(key, value);
    });

    try {
      await fetch("https://formspree.io/f/your-form-id", {
        method: "POST",
        body: data,
        headers: { Accept: "application/json" },
      });
    } catch (error) {
      console.error("Form submission error:", error);
    }
  };

  const aiResponse = formData.ai_opt_in === "yes" && formData.description ? `Based on your situation, our AI suggests we begin with a background verification and initial tailing service.` : "";

  const handleAdminLogin = () => {
    if (password === "admin123") setIsAdmin(true);
    else alert("Incorrect password");
  };

  return (
    <main className="min-h-screen bg-gradient-to-br from-gray-100 to-blue-50 text-gray-900 p-6 space-y-12 font-serif">
      <head>
        <title>Shihan Security | Private Investigation</title>
        <link rel="icon" href="/favicon.ico" />
      </head>

      <header className="text-center bg-white p-8 rounded-2xl shadow-lg animate-fade-in">
        <h1 className="text-6xl font-extrabold text-blue-900 tracking-wider drop-shadow">Shihan Security Specialist, LLC</h1>
        <p className="text-lg mt-2 text-gray-600 italic">Truth. Discretion. Results.</p>
        <p className="mt-4 text-base text-gray-700 max-w-3xl mx-auto">
          A premier private investigation firm offering elite surveillance, fraud analysis, digital forensics, and confidential client services with integrity and precision.
        </p>
      </header>

      {!isAdmin && (
        <section className="bg-white p-6 rounded-2xl shadow animate-fade-in">
          <h2 className="text-xl font-semibold mb-4">Admin Login</h2>
          <input type="password" className="border p-2 rounded mr-2" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Enter admin password" />
          <button className="bg-blue-800 text-white px-4 py-2 rounded" onClick={handleAdminLogin}>Login</button>
        </section>
      )}

      {isAdmin && (
        <section className="bg-white p-6 rounded-2xl shadow animate-fade-in">
          <h2 className="text-2xl font-semibold mb-4">Submission Log</h2>
          {leads.map((lead, index) => (
            <div key={index} className="border rounded p-4 mb-4">
              <p><strong>Name:</strong> {lead.name}</p>
              <p><strong>Email:</strong> {lead.email}</p>
              <p><strong>Service:</strong> {lead.service}</p>
              <p><strong>Description:</strong> {lead.description}</p>
              <textarea className="mt-2 w-full border rounded p-2" placeholder="Add internal notes here..."></textarea>
            </div>
          ))}
        </section>
      )}

      {!isAdmin && (
        <section className="bg-white p-6 rounded-2xl shadow animate-fade-in">
          <h2 className="text-2xl font-semibold mb-4">Request Our Services</h2>
          {submitted ? (
            <div className="text-green-600 font-medium">Thank you for your request. We'll contact you soon!</div>
          ) : (
            <form className="space-y-4" onSubmit={handleSubmit} encType="multipart/form-data">
              <div>
                <label className="block font-medium">Full Name</label>
                <input className="w-full border p-2 rounded" type="text" name="name" value={formData.name} onChange={handleChange} required />
              </div>
              <div>
                <label className="block font-medium">Email Address</label>
                <input className="w-full border p-2 rounded" type="email" name="email" value={formData.email} onChange={handleChange} required />
              </div>
              <div>
                <label className="block font-medium">Choose a Service</label>
                <select className="w-full border p-2 rounded" name="service" value={formData.service} onChange={handleChange}>
                  <option>Surveillance</option>
                  <option>Infidelity Investigation</option>
                  <option>Fraud/Theft Investigation</option>
                  <option>Digital Forensics</option>
                  <option>Other</option>
                </select>
              </div>
              <div>
                <label className="block font-medium">Describe Your Situation</label>
                <textarea className="w-full border p-2 rounded" rows="4" name="description" value={formData.description} onChange={handleChange} placeholder="Tell us what's going on..."></textarea>
              </div>
              <div>
                <label className="block font-medium">Upload Related Files (optional)</label>
                <input className="w-full border p-2 rounded" type="file" name="file" onChange={handleChange} />
              </div>
              <div>
                <label className="block font-medium">Would you like to chat with our AI assistant?</label>
                <select className="w-full border p-2 rounded" name="ai_opt_in" value={formData.ai_opt_in} onChange={handleChange}>
                  <option value="yes">Yes</option>
                  <option value="no">No</option>
                </select>
              </div>
              <button type="submit" className="bg-blue-900 text-white px-6 py-2 rounded hover:bg-blue-800 transition">Submit Request</button>
            </form>
          )}

          {formData.ai_opt_in === "yes" && formData.description && (
            <div className="mt-6 p-4 bg-blue-50 border-l-4 border-blue-700 text-blue-900">
              <strong>AI Suggestion:</strong>
              <p>{aiResponse}</p>
            </div>
          )}
        </section>
      )}

      <section className="bg-white p-6 rounded-2xl shadow animate-fade-in">
        <h2 className="text-xl font-bold mb-4">Frequently Asked Questions</h2>
        <ul className="space-y-4">
          <li><strong>Do you conduct investigations across state lines?</strong><br />Yes, we partner with licensed affiliates and follow state/federal regulations.</li>
          <li><strong>Can I stay anonymous?</strong><br />Yes, confidentiality is guaranteed through a signed agreement before any work begins.</li>
          <li><strong>How soon can we start?</strong><br />Most requests begin within 48 hours of contract and deposit confirmation.</li>
        </ul>
      </section>

      <footer className="text-center text-sm text-gray-500 mt-10">
        &copy; {new Date().getFullYear()} Shihan Security Specialist, LLC. All rights reserved.
      </footer>
    </main>
  );
}
