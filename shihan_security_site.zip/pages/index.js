export default function HomePage() {
  return <div>Shihan Security Specialist, LLC website</div>;
}